__version__ = "0.0.4"

__all__ = [
        'slideEdit',
        'text2audio',
        'revealjs_template',
        ]

